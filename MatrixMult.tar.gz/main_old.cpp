#include<iostream>
#include<cstdio>
#include"Classes.h"
#include<thread>
#include<vector>
#include<mutex>
#include<ctime>


//std::mutex mtx; //utilizzavo mutex per sincronizzare i thread, 
//con un thread per ogni funzione MultiplyTilesOnceOnce, ma non è più necessario con la nuova funzione


void SingleTileThread(int threadId, Matrix Destination, Matrix& A, Matrix& B, int iterations, int i, int j, int tSize){
   //   Destination.MultiplyTilesOnceOnce(A, B, k, i, j, tSize);
   //   std::lock_guard<std::mutex> lock(mtx);
   //int k=0;
   for(int k=0; k<iterations; k++){
      Destination.MultiplyTilesOnce(A, B, k, i, j, tSize);
   }
}

/*
void MultithreadMultiply(Matrix &PA, Matrix &PB, Matrix &PX, int iterations, int i, int j, int tSize, int ThN, vector threads){
   for(i=0; i<PA.Rows()/tSize; i++){
      for(j=0; j<PB.Columns()/tSize; j++){
	 threads.emplace_back([ThN, iterations, i, j, &PA, &PB, PX, &tSize]() {
	    SingleTileThread(ThN, PX, PA, PB, iterations, i, j, tSize);
	 });
	 ThN++;
      }
   }

   for(auto& thread :threads){
      thread.join();
   }
}

*/
int main(int argc, char **argv){

   using namespace std;

   int p;
   int max = 100;
   int best_dimensions = 0;
   double speedup[max];
   double best_result = 0;

   for(p = 1; p<max; p++){
      cout<<"\n\n.------------------------------------------.";
      cout<<p*10<<" righe, le colonne sono la metà\n\n";

      Matrix PA(p*4, p*2);
      Matrix PB(p*2, p*4);

      Matrix PX(p*4, p*4);

      PA.RandomMatrix(500, 900);
      PB.RandomMatrix(130, 400);

      //  A.PrintMatrix();
      //   B.PrintMatrix();

      int tSize = p;

      std::vector<std::thread> threads;
      int ThN = 0;
/*
      Matrix PA = A.AddTilingPaddingRows(tSize);
      Matrix PB = B.AddTilingPaddingColumns(tSize);
      //   PB.PrintMatrix();

      Matrix PX = X.AddTilingPadding(tSize);
*/
      int i, k, j;
      int iterations = PA.Columns()/tSize + 1;



      //testing if it works in serial execution

      clock_t tic_1 = clock();

      for(i=0; i<PA.Rows()/tSize; i++){
	 for(j=0; j<PB.Columns()/tSize; j++){
	    for(k=0; k<iterations; k++){
	       PX.MultiplyTilesOnce(PA, PB, k, i, j, tSize);
	    }
	 }
      }  

      clock_t toc_1 = clock();


      cout<<"Serial execution in "<<(double)(toc_1 - tic_1)/CLOCKS_PER_SEC<<" seconds.\n\n";


      //	PX.PrintMatrix();	

      //   cout<<"\n\n\n--------------Fine esecuzione sequenziale----------------\n\n\n";

      //parallel execution
      clock_t tic = clock();
      for(i=0; i<PA.Rows()/tSize; i++){
	 for(j=0; j<PB.Columns()/tSize; j++){
	    threads.emplace_back([ThN, iterations, i, j, &PA, &PB, PX, &tSize]() {
	       SingleTileThread(ThN, PX, PA, PB, iterations, i, j, tSize);
	    });
	    ThN++;
	 }
      }

      for(auto& thread :threads){
	 thread.join();
      }


      clock_t toc = clock();

      cout<<"Parallel execution in "<<(double)(toc-tic)/CLOCKS_PER_SEC<<" seconds.\n\n";

      speedup[p-1] = ((double)(toc_1-tic_1)/(double)(toc-tic));

      cout<<"Number of Threads: "<<ThN<<endl;
      cout<<"Speedup: "<<speedup[p-1]<<endl;

      //   Matrix M = PX.RemovePadding();
      //   M.PrintMatrix();
      //   PX = PX.RemovePadding();
      //   PX.PrintMatrix();
      if(best_result < speedup[p-1]){
	 best_result = speedup[p-1];
	 best_dimensions = p-1;
	 PA.PrintMatrix();
	 PB.PrintMatrix();
      }


   }

   cout<<"\n\n\nBest: "<<(best_result)<<" obtained with "<<best_dimensions*10<<" rows."<<endl;


   return 0;
}
